# Proguard rules for the app
-keep class com.rudev.taskmanager.data.** { *; }
