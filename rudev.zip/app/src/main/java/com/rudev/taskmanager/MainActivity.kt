package com.rudev.taskmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.rudev.taskmanager.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "task-database"
        ).build()
        
        val viewModel = TaskViewModel(db.taskDao())

        setContent {
            MaterialTheme(
                colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    TaskApp(viewModel)
                }
            }
        }
    }
}

class TaskViewModel(private val taskDao: TaskDao) : ViewModel() {
    val tasks = taskDao.getAllTasks()
    val categories = taskDao.getAllCategories()

    fun addTask(title: String, dueDate: String, dueTime: String, catId: Int?) {
        viewModelScope.launch {
            taskDao.insertTask(Task(title = title, dueDate = dueDate, dueTime = dueTime, categoryId = catId))
        }
    }

    fun toggleTaskStatus(task: Task) {
        val nextStatus = when (task.status) {
            TaskStatus.NOT_STARTED -> TaskStatus.IN_PROGRESS
            TaskStatus.IN_PROGRESS -> TaskStatus.COMPLETED
            TaskStatus.COMPLETED -> TaskStatus.NOT_STARTED
            TaskStatus.OVERDUE -> TaskStatus.COMPLETED
        }
        viewModelScope.launch {
            taskDao.updateTask(task.copy(status = nextStatus, updatedAt = System.currentTimeMillis()))
        }
    }

    fun deleteTask(task: Task) {
        viewModelScope.launch {
            taskDao.deleteTask(task)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskApp(viewModel: TaskViewModel) {
    val tasks by viewModel.tasks.collectAsStateWithLifecycle(initialValue = emptyList())
    val categories by viewModel.categories.collectAsStateWithLifecycle(initialValue = emptyList())
    
    var showAddDialog by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryId by remember { mutableStateOf<Int?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("RuDev Task Manager", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = { /* Settings */ }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add Task")
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            // Stats Row
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
               StatsCard("Активные", tasks.count { it.status != TaskStatus.COMPLETED }.toString(), Color(0xFF2196F3), Modifier.weight(1f))
               StatsCard("Просрочено", tasks.count { it.status == TaskStatus.OVERDUE }.toString(), Color(0xFFF44336), Modifier.weight(1f))
               StatsCard("Архив", tasks.count { it.status == TaskStatus.COMPLETED }.toString(), Color(0xFF4CAF50), Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Categories Row
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    CategoryChip("Все", selectedCategoryId == null) { selectedCategoryId = null }
                }
                items(categories) { cat ->
                    CategoryChip(cat.name, selectedCategoryId == cat.id) { selectedCategoryId = cat.id }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Поиск...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Task List
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val filteredTasks = tasks.filter { 
                    (selectedCategoryId == null || it.categoryId == selectedCategoryId) &&
                    (it.title.contains(searchQuery, ignoreCase = true))
                }
                
                items(filteredTasks) { task ->
                    TaskItem(task, onToggle = { viewModel.toggleTaskStatus(task) }, onDelete = { viewModel.deleteTask(task) })
                }
            }
        }
    }

    if (showAddDialog) {
        // Простой диалог добавления (в реальном приложении лучше использовать полноценный ModalBottomSheet)
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Новая задача") },
            text = {
                var title by remember { mutableStateOf("") }
                Column {
                    TextField(value = title, onValueChange = { title = it }, placeholder = { Text("Название") })
                }
            },
            confirmButton = {
                Button(onClick = { 
                    viewModel.addTask("Новая задача", "2026-05-04", "12:00", null)
                    showAddDialog = false 
                }) {
                    Text("Добавить")
                }
            }
        )
    }
}

@Composable
fun StatsCard(label: String, count: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(label.uppercase(), fontSize = 10.sp, fontWeight = FontWeight.Black, color = color)
            Text(count, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun CategoryChip(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(label, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun TaskItem(task: Task, onToggle: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = task.status == TaskStatus.COMPLETED, onCheckedChange = { onToggle() })
            Column(modifier = Modifier.weight(1f).padding(start = 8.dp)) {
                Text(task.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("${task.dueDate} в ${task.dueTime}", fontSize = 12.sp, color = Color.Gray)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray)
            }
        }
    }
}
