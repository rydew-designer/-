import Dexie, { Table } from 'dexie';

export enum TaskStatus {
  NOT_STARTED = 'not_started',
  IN_PROGRESS = 'in_progress',
  OVERDUE = 'overdue',
  COMPLETED = 'completed'
}

export interface Category {
  id?: number;
  name: string;
  color?: string;
}

export interface Task {
  id?: number;
  title: string;
  comment: string;
  category: string;
  categoryId?: number;
  dueDate: string; // ISO string for date context
  dueTime: string; // HH:mm format
  status: TaskStatus;
  reminders?: number[]; // Array of minutes before due date
  createdAt: number;
  updatedAt: number;
}

export class MyDatabase extends Dexie {
  tasks!: Table<Task>;
  categories!: Table<Category>;

  constructor() {
    super('TaskMasterDB');
    
    this.version(3).stores({
      tasks: '++id, title, dueDate, status, createdAt, category'
    }).upgrade(tx => {
      return tx.table('tasks').toCollection().modify(task => {
        if (!task.category) task.category = 'Общее';
      });
    });

    this.version(4).stores({
      tasks: '++id, title, dueDate, status, createdAt, categoryId',
      categories: '++id, &name'
    }).upgrade(async tx => {
      const tasks = await tx.table('tasks').toArray();
      const uniqueNames = Array.from(new Set(tasks.map(t => t.category || 'Общее')));
      const nameToId: Record<string, number> = {};
      for (const name of uniqueNames) {
        const id = await tx.table('categories').add({ name });
        nameToId[name] = id;
      }
      await tx.table('tasks').toCollection().modify(task => {
        task.categoryId = nameToId[task.category || 'Общее'];
      });
    });

    this.version(5).stores({
      tasks: '++id, title, dueDate, status, createdAt, categoryId',
      categories: '++id, &name',
      settings: 'id'
    });
  }
}

export interface Setting {
  id: string;
  value: any;
}

export const db = new MyDatabase();
