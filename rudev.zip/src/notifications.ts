import { format, isAfter, parseISO, subMinutes, subHours } from 'date-fns';
import { db, Task, TaskStatus } from './db';

// Simple in-app notification state (could be replaced by browser Notification API)
export const requestNotificationPermission = async () => {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  const status = await Notification.requestPermission();
  return status === 'granted';
};

export const sendNotification = async (title: string, body: string) => {
  // Play custom sound if set
  try {
    const soundSetting = await (db as any).settings.get('notificationSound');
    if (soundSetting && soundSetting.value) {
      const audio = new Audio(soundSetting.value);
      audio.play().catch(e => console.error('Error playing notification sound:', e));
    }
  } catch (e) {
    console.error('Error reading sound setting:', e);
  }

  if ('Notification' in window && Notification.permission === 'granted') {
    new Notification(title, { body, icon: '/favicon.ico' });
  } else {
    // Fallback or debug
    console.log(`Notification: ${title} - ${body}`);
  }
};

/**
 * Schedule pseudo-notifications using a list of scheduled checks.
 * In a real app, this would be a Service Worker or a robust background sync.
 */
export const checkTaskNotifications = (tasks: Task[]) => {
  const now = new Date();
  
  tasks.forEach(task => {
    if (task.status === TaskStatus.COMPLETED || task.status === TaskStatus.OVERDUE) return;

    const dueDateTime = parseISO(`${task.dueDate}T${task.dueTime}`);
    
    // Check for Overdue
    if (isAfter(now, dueDateTime)) {
      // Mark as overdue logic will be in the main loop
      return;
    }

    // Use custom reminders if available, otherwise use defaults
    const reminderMinutes = task.reminders && task.reminders.length > 0 
      ? task.reminders 
      : [1440, 60, 30, 5]; // Default: 24h, 1h, 30m, 5m

    reminderMinutes.forEach((mins) => {
      const reminderTime = subMinutes(dueDateTime, mins);
      const isTimeNow = Math.abs(now.getTime() - reminderTime.getTime()) < 30000; // Within 30 seconds window

      if (isTimeNow) {
        let label = `${mins} мин.`;
        if (mins >= 1440) label = `${Math.floor(mins / 1440)} дн.`;
        else if (mins >= 60) label = `${Math.floor(mins / 60)} ч.`;
        
        sendNotification('RuDev: Напоминание', `Задача "${task.title}" начнется через ${label}`);
      }
    });
  });
};
