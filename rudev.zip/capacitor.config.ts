import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.rudev.taskmaster',
  appName: 'RuDev Task Manager',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  }
};

export default config;
